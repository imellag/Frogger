// stampa il marciapiede
void funzMarciapiede();
