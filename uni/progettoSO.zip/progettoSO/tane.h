#pragma once
#include <stdbool.h>

// inizializza lo sfondo delle tane
void funzTane(bool arrayTane[]);
// stampa le tane effettive, facendo differenza tra quelle aperte e quelle chiuse
void stampaTane(bool arrayTane[]);