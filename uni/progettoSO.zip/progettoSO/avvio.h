// menu iniziale di gioco
int menuIniziale();
// stampa la sprite della scritta frogger
void stampaFrogger(int iniziox, int inizioy);
// stampa i rettangoli contenenti gli input possibili
void stampaRettangoli();